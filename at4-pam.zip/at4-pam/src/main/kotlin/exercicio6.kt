fun main() {
    println("Cloudy")
    println("Partly Cloudy")
    println("Windy")
}