fun main() {
    println("1")
    println("2")
    println("3")
}