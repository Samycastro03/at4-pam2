fun main() {
    println("I'm")
    println("learning")
    println("Kotlin!")
}