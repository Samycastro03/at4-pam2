fun main() {
    println("Tomorrow is rainy")
}