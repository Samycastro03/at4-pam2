fun main() {
    println("There is a chance of snow")
}
