fun main() {
    println("How's the weather today?")
}